globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/90YurKU1L05ZF4HFRtByA/_buildManifest.js",
    "static/90YurKU1L05ZF4HFRtByA/_ssgManifest.js",
    "static/90YurKU1L05ZF4HFRtByA/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1inwntv0b4r-7.js",
    "static/chunks/1rgam1zzcgpcb.js",
    "static/chunks/08ttfj81-47mu.js",
    "static/chunks/turbopack-1h4kumj8d5ekb.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
